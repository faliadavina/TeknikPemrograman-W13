package com.polban.tekpro.monopoly.gui;

import com.polban.tekpro.monopoly.Cell;

public interface CellInfoFormatter {
    public String format(Cell cell);
}
