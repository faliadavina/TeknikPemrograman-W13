package com.polban.tekpro.monopoly;

public interface RespondDialog {
    boolean getResponse();
}
