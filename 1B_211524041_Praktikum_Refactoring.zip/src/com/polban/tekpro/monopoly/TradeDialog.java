package com.polban.tekpro.monopoly;

public interface TradeDialog {
    TradeDeal getTradeDeal();
}
